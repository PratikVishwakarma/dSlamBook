<?php
		$servername = "localhost";
		$database = "sbusers";
		$dbusername = "pratik";
		$password = "pratik";
        
        $con = mysqli($servername, $dbusername, $password, $database);
?>
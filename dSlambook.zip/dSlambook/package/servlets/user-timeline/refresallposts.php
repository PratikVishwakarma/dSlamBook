<?php

class refresallposts {
    //put your code here
}

<?php
    $phpsbabout = "phpsbabout";    
    $phpsbusers = "phpsbusers";
    $phpsbstatus = "phpsbstatus";
    $phpsbabout = "phpsbabout";
    $phpsbphotos = "phpsbphotos";
    $phpsbfriends = "phpsbfriends";
?>
